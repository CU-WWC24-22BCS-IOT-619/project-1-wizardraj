<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fertilizer Impact Prediction</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
            color: #333;
        }

        header {
            background-color: #4CAF50;
            color: white;
            padding: 1rem 0;
            text-align: center;
        }

        main {
            padding: 2rem;
            max-width: 1200px;
            margin: 0 auto;
        }

        section {
            margin-bottom: 2rem;
            background: white;
            border-radius: 8px;
            padding: 1.5rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: #4CAF50;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }

        select, input, button {
            padding: 0.75rem;
            font-size: 1rem;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        button {
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #45a049;
        }

        footer {
            text-align: center;
            padding: 1rem;
            background: #333;
            color: white;
            position: fixed;
            width: 100%;
            bottom: 0;
        }

        #prediction-result {
            margin-top: 1rem;
            padding: 1rem;
            background: #e8f5e9;
            border-left: 4px solid #4CAF50;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <header>
        <h1>Fertilizer Impact Prediction</h1>
        <p>Using AI and Data Analytics to Enhance Crop Growth</p>
    </header>

    <main>
        <section id="introduction">
            <h2>About the Model</h2>
            <p>Our predictive model analyzes and forecasts the impact of different fertilizers on crop growth. Leveraging AI and data analytics, we aim to improve yield, reduce costs, and provide actionable insights for better farming decisions.</p>
        </section>

        <section id="features">
            <h2>Features</h2>
            <ul>
                <li><strong>Predictive Analysis:</strong> Forecast fertilizer effects on crops.</li>
                <li><strong>Yield Improvement:</strong> Suggest optimal fertilizer combinations.</li>
                <li><strong>Cost Efficiency:</strong> Maximize crop output per unit of fertilizer.</li>
                <li><strong>Data Insights:</strong> Use data for informed decisions.</li>
                <li><strong>Crop Health Monitoring:</strong> Track the effects on crop quality.</li>
            </ul>
        </section>

        <section id="prediction-tool">
            <h2>Prediction Tool</h2>
            <form id="prediction-form">
                <label for="crop-type">Select Crop Type:</label>
                <select id="crop-type" name="crop-type">
                    <option value="wheat">Wheat</option>
                    <option value="rice">Rice</option>
                    <option value="maize">Maize</option>
                    <option value="soybean">Soybean</option>
                </select>

                <label for="fertilizer-type">Select Fertilizer Type:</label>
                <select id="fertilizer-type" name="fertilizer-type">
                    <option value="nitrogen">Nitrogen</option>
                    <option value="phosphorus">Phosphorus</option>
                    <option value="potassium">Potassium</option>
                    <option value="mixed">Mixed</option>
                </select>

                <label for="quantity">Enter Fertilizer Quantity (kg):</label>
                <input type="number" id="quantity" name="quantity" min="1" required>

                <button type="submit">Predict Impact</button>
            </form>
            <div id="prediction-result">
                <!-- Results will be displayed here -->
            </div>
        </section>
    </main>

    <footer>
        <p> </p>
    </footer>

    <script>
        document.getElementById('prediction-form').addEventListener('submit', function(event) {
            event.preventDefault();
            const cropType = document.getElementById('crop-type').value;
            const fertilizerType = document.getElementById('fertilizer-type').value;
            const quantity = document.getElementById('quantity').value;

            const resultDiv = document.getElementById('prediction-result');
            resultDiv.innerHTML = `<p>Predicting impact for <strong>${cropType}</strong> using <strong>${fertilizerType}</strong> fertilizer (${quantity} kg)...</p>`;
        });
    </script>
</body>
</html>
upm add flask